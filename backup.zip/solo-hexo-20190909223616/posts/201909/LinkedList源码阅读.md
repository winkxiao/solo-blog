title: LinkedList源码阅读
date: '2019-09-06 23:37:01'
updated: '2019-09-06 23:37:01'
tags: [JAVASE, JAVA基础]
permalink: /articles/2019/09/06/1567784220984.html
---
# LinkedList

## 类继承即实现体系