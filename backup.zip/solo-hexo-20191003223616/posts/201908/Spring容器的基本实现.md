title: Spring-容器的基本实现
date: '2019-08-20 21:29:34'
updated: '2019-10-03 14:12:32'
tags: [spring源码深度解析, 源码]
permalink: /articles/2019/08/20/1566307774791.html
---
# Spring-容器的实现
## IOC/DI

### IOC(Inversion of Control)控制反转
控制反转，就是把原先我们代码里面需要实现的对象创建、依赖的代码，反转给Spring容器来实现。那么必然先需要创建一个容器，同时需要一种**描述来让容器知道需要创建的对象与对象的关系**。这个描述最具体表现就是我们**可配置的文件**。

### DI(Dependency Injection)依赖注入
指对象是被动接受依赖类而不是自己主动去找；  
即**对象不是从容器中查找它依赖的类，而是在容器实例化对象的时候主动将它依赖的类注入给它**。

* **如何设计一个IOC容器？**
1. 对象和对象关系怎么表示？  
    可以用 xml，properties 文件等语义化配置文件表示。
2. 描述对象关系的文件存放在哪里？  
    可能是 classpath，filesystem，或者是 URL 网络资源，servletContext 等。

* **对配置文件解析**  

1. 不同的配置文件对对象的描述不一样，如何统一？  
在内部需要有一个统一的关于对象的定义，所有外部的描述都必须转化成统一的描述定义（beanDefinition）。  
2. 如何对不同的配置文件进行解析？  
需要对不同的配置文件语法，采用不同的解析器。

#### 如何理解IOC和DI
个人理解IOC是一种设计思想，设计理念，改变了原有依赖关系。  而DI就是IOC的具体实现；  
**即设计好的对象交给容器控制，而不是传统的在你的对象内部直接控制(new)，由容器给予相应依赖。**   
* **反转控制：**   
    * 谁控制谁？控制什么？  
    **即由Ioc容器来控制对象的创建，IoC器控制了对象**  
    * 什么是反转？哪些方面反转？  
    **由容器帮我们查找创建及注入依赖对象，对象只是被动的接受依赖对象，是反转；  
    依赖对象的获取被反转了。**

## Spring 核心容器体系结构
### BeanFactory
* **关系类图**  

![image](https://s2.ax1x.com/2019/10/01/uUTvdO.png)  

BeanFactory作为最顶层的一个接口类，它定义了IOC容器的基本功能规范。  
BeanFactory有三个直接的子类：**ListableBeanFactory、HierarchicalBeanFactory 和 AutowireCapableBeanFactory**。
但是从上图中我们可以发现最终的**默认实现类是DefaultListableBeanFactory**，他实现了所有的接口。那为何要定义这么多层次的接口呢？查阅这些接口的源码和说明发现，每个接口都有他使用的场合，它主要是为了区分在 Spring内部在操作过程中对象的传递和转化过程中，对对象的数据访问所做的限制。例如**ListableBeanFactory接口表示这些Bean是可列表的**，而**HierarchicalBeanFactory表示的是这些Bean是有继承关系的**，也就是每个Bean有可能有父Bean。**AutowireCapableBeanFactory接口定义Bean的自动装配规则**。这四个接口共同定义了Bean的集合、Bean之间的关系、以及 Bean行为。  
  
**BeanFactory 里只对 IOC容器的基本行为作了定义，根本不关心你的 Bean 是如何定义怎样加载的。**

```
public interface BeanFactory {
//对 FactoryBean 的转义定义，因为如果使用 bean 的名字检索 FactoryBean 得到的对象是工厂生成的对象，
//如果需要得到工厂本身，需要转义
String FACTORY_BEAN_PREFIX = "&";
//根据 bean 的名字，在 IOC 容器中获取 bean 实例
Object getBean(String name) throws BeansException;
//根据 bean 的名字和 Class 类型来得到 bean 实例，增加了类型安全验证机制。
<T> T getBean(String name, @Nullable Class<T> requiredType) throws BeansException;
//根据名字和参数 在IOC容器中获取bean的实例
Object getBean(String name, Object... args) throws BeansException;
<T> T getBean(Class<T> requiredType) throws BeansException;
//根据类型和参数 在IOC容器中获取bean的实例
<T> T getBean(Class<T> requiredType, Object... args) throws BeansException;
//提供对 bean 的检索，看看是否在 IOC 容器有这个名字的 bean
boolean containsBean(String name);
//根据 bean 名字得到 bean 实例，并同时判断这个 bean 是不是单例
boolean isSingleton(String name) throws NoSuchBeanDefinitionException;
boolean isPrototype(String name) throws NoSuchBeanDefinitionException;
boolean isTypeMatch(String name, ResolvableType typeToMatch) throws NoSuchBeanDefinitionException;
boolean isTypeMatch(String name, @Nullable Class<?> typeToMatch) throws NoSuchBeanDefinitionException;
//得到 bean 实例的 Class 类型
@Nullable
Class<?> getType(String name) throws NoSuchBeanDefinitionException;
//得到 bean 的别名，如果根据别名检索，那么其原名也会被检索出来
String[] getAliases(String name);
}
```


### BeanDefinition
SpringIOC 容器管理了我们定义的各种 Bean 对象及其相互的关系，Bean 对象在 **Spring 实现中是以 BeanDefinition来描述的。**

* 类图  

![image](https://s2.ax1x.com/2019/10/01/uU7mFg.png)

* Bean解析类  
**Bean的解析主要就是对Spring配置文件的解析。**
 ![image](https://s2.ax1x.com/2019/10/01/uU7uWj.png)

## IOC 容器的初始化
IOC 容器的初始化包括 BeanDefinition的Resource **定位、载入和注册**这三个基本的过程。

**定位**：找到配置文件位置  
**载入**：通过DOM4J解析XML配置文件，解析成BeanDefinition保存到内存里。  
**注册**：将BeanDefinition的信息，存入工厂里Map；

* 继承图  
![image](https://s2.ax1x.com/2019/10/02/uU7tkF.png)

#### IOC 容器的创建过程
##### 1. XmlBeanFactory的IOC容器流程
1. 定位是为了获得Resource
2. 载入是通过BeanDefinitionReader解析XML获得BeanDefinition
3. 注册是将BeanDefinition存入工厂ListableBeanFactory的Map容器中
* 源码
![image](https://s2.ax1x.com/2019/10/01/uUES9s.png)

```
// 根据 Xml 配置文件创建 Resource 资源对象，该对象中包含了 BeanDefinition 的信息
ClassPathResource resource = new ClassPathResource("application-context.xml");
// 创建 DefaultListableBeanFactory
DefaultListableBeanFactory factory = new DefaultListableBeanFactory();
//创建 XmlBeanDefinitionReader 读取器，用于载入 BeanDefinition。
// 之所以需要 BeanFactory 作为参数，是因为会将读取的信息回调配置给 factory
XmlBeanDefinitionReader reader = new XmlBeanDefinitionReader(factory);
// XmlBeanDefinitionReader 执行载入 BeanDefinition 的方法，最后会完成 Bean 的载入和注册。
// 完成后 Bean 就成功的放置到 IOC 容器当中，以后我们就可以从中取得 Bean 来使用
reader.loadBeanDefinitions(resource);
```

##### 2. FileSystemXmlApplicationContext的IOC容器流程
1. 构造函数  
    a. 调用父类容器的构造方法(super(parent)方法)**为容器设置好 Bean 资源加载器**。  
    b. 父类AbstractRefreshableConfigApplicationContext 的setConfigLocations(configLocations)方法**设置 Bean定义资源文件的定位路径**。
![image](https://s2.ax1x.com/2019/10/01/uUZe61.png)   

* 父类AbstractApplicationContext中初始化IOC容器所做  
    1. static代码块初始化加载容器关闭事件
    2. **获取Spring Source的加载器**用于读入Spring Bean定义资源文件
    ![image](https://s2.ax1x.com/2019/10/01/uUZtXt.png)
    3. 父类AbstractRefreshableConfigApplicationContext 的方法进行**对Bean定义资源文件的定位**，setConfigLocations()[解析配置文件位置的字符串]  
    ![image](https://s2.ax1x.com/2019/10/02/uU7jcn.png)
2. AbstractApplicationContext的refresh函数**载入**Bean定义过程  
```
//容器初始化的过程，载入Bean定义资源，并解析注册
	@Override
	public void refresh() throws BeansException, IllegalStateException {
		synchronized (this.startupShutdownMonitor) {
			//调用容器准备刷新的方法，获取容器的当时时间，同时给容器设置同步标识
			prepareRefresh();

			// 告诉子类启动refreshBeanFactory（）方法，Bean定义资源文件的载入从子类的refreshBeanFactory
			ConfigurableListableBeanFactory beanFactory = obtainFreshBeanFactory();

			// 准备beanFactory：为BeanFactory配置容器特性，例如类加载器、事件处理器等
			prepareBeanFactory(beanFactory);

			try {
				//后置事件：为容器的某些子类指定特殊的BeanPost事件处理器
				postProcessBeanFactory(beanFactory);

				// 调用所有注册的BeanFactoryPostProcessor的Bean
				invokeBeanFactoryPostProcessors(beanFactory);

				//为BeanFactory注册BeanPost事件处理器。
				//BeanPostProcessor是Bean后置处理器，用于监听容器触发的事件
				registerBeanPostProcessors(beanFactory);

				//初始化信息源，和国际化相关。
				initMessageSource();

				// 初始化容器事件传播器
				initApplicationEventMulticaster();

				//调用子类的某些特殊Bean初始化方法
				onRefresh();

				//为事件传播器注册事件监听器。
				registerListeners();

				//初始化所有剩余的单例Bean.
				finishBeanFactoryInitialization(beanFactory);

				//初始化容器的生命周期事件处理器，并发布容器的生命周期事件
				finishRefresh();
			}

			catch (BeansException ex) {
				if (logger.isWarnEnabled()) {
					logger.warn("Exception encountered during context initialization - " +
							"cancelling refresh attempt: " + ex);
				}

				//销毁已创建的单例Bean
				destroyBeans();

				//取消refresh操作，重置容器的同步标识。
				cancelRefresh(ex);

				// Propagate exception to caller.
				throw ex;
			}

			finally {
				// Reset common introspection caches in Spring's core, since we
				// might not ever need metadata for singleton beans anymore...
				resetCommonCaches();
			}
		}
	}
```
**SpringIOC容器载入Bean定义资源文件从其子类容器的refreshBeanFactory() 方法开始**。所以整个refresh()中
“ConfigurableListableBeanFactorybeanFactory=obtainFreshBeanFactory();”这句以后代码的都是**注册容器的信息源和生命周期事件，载入过程就是从这句代码启动**。

* **refresh()方法的作用是**：  
在创建IOC容器前，如果已经有容器存在，则需要把已有的容器销毁和关闭，以保证在refresh 之后使用的是新建立起来的IOC容器。refresh 的作用类似于对 **IOC容器的重启（IOC是单例的），在新建立好的容器中对容器进行初始化，对Bean定义资源进行载入**

3. AbstractApplicationContext的**obtainFreshBeanFactory()** 方法调用子类容器的refreshBeanFactory()方法，启动容器载入Bean定义资源文件
![image](https://s2.ax1x.com/2019/10/02/uUHQ4e.png)

```
@Override
	protected final void refreshBeanFactory() throws BeansException {
		if (hasBeanFactory()) {
			//1. 如果已经有容器，销毁容器中的bean，关闭容器
			destroyBeans();
			closeBeanFactory();
		}
		try {
			//2.创建IOC容器
			DefaultListableBeanFactory beanFactory = createBeanFactory();
			beanFactory.setSerializationId(getId());
			//对IOC容器进行定制化，如设置启动参数，开启注解的自动装配等
			customizeBeanFactory(beanFactory);
			//3.调用载入Bean定义的方法，主要这里又使用了一个委派模式，
			//在当前类中只定义了抽象的1oadBeanDefinitions方法，具体的实现调用子类容器
			loadBeanDefinitions(beanFactory);
			synchronized (this.beanFactoryMonitor) {
				this.beanFactory = beanFactory;
			}
		}
		catch (IOException ex) {
			throw new ApplicationContextException("I/O error parsing bean definition source for " + getDisplayName(), ex);
		}
	}
```
![image](https://s2.ax1x.com/2019/10/02/uUHaE8.png)
![image](https://s2.ax1x.com/2019/10/02/uUHcD0.png)

4. AbstractBeanDefinitionReader读取Bean定义资源loadBeanDefinitions方法

```
//载入XML形式Bean定义资源文件方法
	public int loadBeanDefinitions(String location, @Nullable Set<Resource> actualResources) throws BeanDefinitionStoreException {
		//获取在IOC容器初始化过程中设置的资源加载器
		ResourceLoader resourceLoader = getResourceLoader();
		if (resourceLoader == null) {
			throw new BeanDefinitionStoreException(
					"Cannot load bean definitions from location [" + location + "]: no ResourceLoader available");
		}

		if (resourceLoader instanceof ResourcePatternResolver) {
			// Resource pattern matching available.
			try {
				//将指定位置的Bean定义资源文件解析为Spring IoC容器封装的资源
				//加载多个指定位置的Bean定义资源文件
				Resource[] resources = ((ResourcePatternResolver) resourceLoader).getResources(location);
				//委派调用其子类XmlBeanDefinitionReader的方法，实现加载功能，IO流
				int count = loadBeanDefinitions(resources);
				if (actualResources != null) {
					Collections.addAll(actualResources, resources);
				}
				if (logger.isTraceEnabled()) {
					logger.trace("Loaded " + count + " bean definitions from location pattern [" + location + "]");
				}
				return count;
			}
			catch (IOException ex) {
				throw new BeanDefinitionStoreException(
						"Could not resolve bean definition resource pattern [" + location + "]", ex);
			}
		}
		else {
			//将指定位置的Bean定义资源文件解析为Spring IOC容器封装的资源
			//加载单个指定位置的Bean定义资源文件
			Resource resource = resourceLoader.getResource(location);
			//委派调用其子类XmlBeanDefinitionReader的方法，实现加载功能
			int count = loadBeanDefinitions(resource);
			if (actualResources != null) {
				actualResources.add(resource);
			}
			if (logger.isTraceEnabled()) {
				logger.trace("Loaded " + count + " bean definitions from location [" + location + "]");
			}
			return count;
		}
	}
```
![image](https://s2.ax1x.com/2019/10/02/uUbtz9.png)

```
//是载入XML形式Bean定义资源文件方法
	public int loadBeanDefinitions(EncodedResource encodedResource) throws BeanDefinitionStoreException {
		Assert.notNull(encodedResource, "EncodedResource must not be null");
		if (logger.isTraceEnabled()) {
			logger.trace("Loading XML bean definitions from " + encodedResource);
		}

		Set<EncodedResource> currentResources = this.resourcesCurrentlyBeingLoaded.get();
		if (currentResources == null) {
			currentResources = new HashSet<>(4);
			this.resourcesCurrentlyBeingLoaded.set(currentResources);
		}
		if (!currentResources.add(encodedResource)) {
			throw new BeanDefinitionStoreException(
					"Detected cyclic loading of " + encodedResource + " - check your import definitions!");
		}
		try {
			//将资源文件转为Inputstream的IO流
			InputStream inputStream = encodedResource.getResource().getInputStream();
			try {
				//从InputStream中得到XML的解析源
				InputSource inputSource = new InputSource(inputStream);
				if (encodedResource.getEncoding() != null) {
					inputSource.setEncoding(encodedResource.getEncoding());
				}
				//这里是真正具体的读取过程
				return doLoadBeanDefinitions(inputSource, encodedResource.getResource());
			}
			finally {
				inputStream.close();
			}
		}
		catch (IOException ex) {
			throw new BeanDefinitionStoreException(
					"IOException parsing XML document from " + encodedResource.getResource(), ex);
		}
		finally {
			currentResources.remove(encodedResource);
			if (currentResources.isEmpty()) {
				this.resourcesCurrentlyBeingLoaded.remove();
			}
		}
	}
```

**两件事**：  
①.调用资源加载器的获取资源方法resourceLoader.getResource(location)，**获取到要加载的资源**； 
![image](https://s2.ax1x.com/2019/10/02/uaRgCq.png)   
②.调用真正**执行加载功能**，其子类XmlBeanDefinitionReader的loadBeanDefinitions方法   

5. resourceLoader.getResource(location)，获取到要加载的资源  
FileSystemXmlApplicationContext本身就是DefaultResourceLoader的**实现类**，所以此时又回到了FileSystemXmlApplicationContext中来。
6. 实际载入bean定义资源文件的方法
![image](https://s2.ax1x.com/2019/10/02/uaWgdH.png)   

7. DocumentLoader将Bean定义资源转换为Document对象：  
以上已经对bean资源文件进行定位、载入完毕

8. XmlBeanDefinitionReader解析载入的Bean定义资源文件
 XmlBean  DefinitionReader类中的doLoadBeanDefinitions方法是从特定XML文件中实际载入Bean定义资源的方法，该方法在载入Bean定义资源之后将其转换为Document对象，接下来调用registerBeanDefinitions启动SpringIOC容器对Bean定义的解析过程
![image](https://s2.ax1x.com/2019/10/02/uahagx.png)
Bean定义资源的载入解析分为两个过程：  
    ①调用XML解析器将Bean定义资源文件转换得到Document对象   
    ②按照Spring的Bean规则对Document对象进行解析
> DefaultBeanDefinitionDocumentReader#doRegisterBeanDefinitions.doRegisterBeanDefinitions(Element root)来解析,具体的解析过程由BeanDefinitionParserDelegate实现

解析具体标签：  
a.Spring配置文件中使用<import>元素来导入IOC容器所需要的其他资源，SpringIOC容器在解析时会首先将指定导入的资源加载进容器中。使用<ailas>别名时，SpringIOC容器首先将别名元素所定义的别名注册到容器中。   
b.**解析<Bean>元素过程中没有创建和实例化Bean对象，只是创建了Bean对象的定义类BeanDefinition**   
c.<Bean>元素中<property>元素  
    a. ref被封装为指向依赖对象一个引用。  
    b. value配置都会封装成一个字符串类型的对象。  
    c. ref和value都通过“解析的数据类型属性值.setSource(extractSource(ele));”方法将属性值/引用与所引用的属性关联起来。

SpringBean定义资源文件转换的Document对象中的元素层层解析，SpringIOC现在已经**将XML形式定义的Bean定义资源文件转换为SpringIOC所识别的数据结构——BeanDefinition**，它是Bean定义资源文件中配置的POJO对象在SpringIOC容器中的映射。

9. 解析过后的BeanDefinition在IOC容器中的注册：  
**完成对Document对象的解析后得到封装BeanDefinition的BeanDefinitionHold对象**
10. BeanDefinitionReaderUtils的registerBeanDefinition方法向IOC容器注册解析的Bean   
**真正完成注册功能的是DefaultListableBeanFactory。**
11. DefaultListableBeanFactory向IOC容器注册解析后的BeanDefinition  
DefaultListableBeanFactory中使用一个HashMap的集合对象存放IOC容器中注册解析的BeanDefinition  
![image](https://s2.ax1x.com/2019/10/02/uaobwT.png)
> IOC容器中已经建立**了整个Bean的配置信息**，这些BeanDefinition信息已经可以使用，并且可以被检索，IOC容器的作用就是对这些注册的Bean定义信息进行处理和维护。这些的注册的Bean定义信息是IOC容器控制反转的基础，正是有了这些注册的数据，容器才可以进行依赖注入。   

### 总结
(1)初始化的入口在**容器实现中的refresh()** 调用来完成。  
(2)对bean定义载入IOC容器使用的方法是loadBeanDefinition；  
    ①**通过ResourceLoader来完成资源文件位置的定位**，DefaultResourceLoader是默认的实现，同时application本身就给出了ResourceLoader的实现，可以从类路径，文件系统,URL等方式来定为资源位置  
    **bean定义文件时通过抽象成Resource来被IOC容器处理**  
    ②容器通过BeanDefinitionReader来完成定义信息的解析和Bean信息的注册  
    ③实际解析处理过程是委托给**BeanDefinitionParserDelegate**来做的，从而得到bean的定义信息  
    loadBeanDefinition,RegisterBeanDefinition相关方法-为处理BeanDefinitin， 
(3)对beanDefinition的注册时registerBeanDefinition方法。  
①BeanDefinition，需要在IOC容器中注册，由IOC实现BeanDefinitionRegistry接口  
②**注册过程就是在IOC容器内部维护的ConcurrentHashMap来put保存得到的BeanDefinition的过程。**

> 这个Map是IOC容器持有Bean信息的场所，以后对Bean的操作都是围绕这个HashMap来实现的。  

#### 时序图
![image](https://s2.ax1x.com/2019/10/02/ua7Brt.png)

#### BeanFactory和FactoryBean的区别
**BeanFactory指的是IOC容器的编程抽象**，比如ApplicationContext，XmlBeanFactory等，都是IOC容器的具体实现。  
FactoryBean(**IOC生成的一个工厂Bean用来生产其他Bean对象，spring以&标识**)只是一个可以**在IOC而容器中被管理的一个Bean**,是对各种**处理过程和资源使用的抽象**。  
所有FactoryBean都实现特殊的FactoryBean接口，当使用容器中FactoryBean的时候，该容器不会返回FactoryBean本身,而是**返回其生成的对象**，可以看成是一个抽象工厂。  

> **Spring通过使用抽象工厂模式为我们准备了一系列工厂来生产一些特定的对象**
