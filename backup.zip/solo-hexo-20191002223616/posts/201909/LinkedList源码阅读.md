title: LinkedList源码阅读
date: '2019-09-06 23:37:01'
updated: '2019-09-17 23:30:06'
tags: [JAVASE, JAVA基础]
permalink: /articles/2019/09/06/1567784220984.html
---
# LinkedList

**是可以被当作堆栈、队列或双端队列进行操作。**
## 类继承及实现体系

    public class LinkedList<E>
        extends AbstractSequentialList<E>
        implements List<E>, Deque<E>, Cloneable, java.io.Serializable

- 继承
  AbstractSequentialList：AbstractSequentialList是继承AbstractList抽象类，也可以随机访问，但是必须遍历，PS：主要是Iterator迭代器的方法实现。
- 实现
  List：实现该接口，是为了代码语义化更清晰，反射能拿到实现的接口。PS：听大佬说的；存取有序
  Deque：双端队列，即可以从首节点插入取出或尾节点插入取出，Deque 继承 Queue，LinkedList也是队列的数据结构。
  Cloneable：实现了Cloneable接口，即覆盖了函数clone()，能克隆。
  Serializable：实现java.io.Serializable接口，这意味着LinkedList支持序列化，能通过序列化去传输。

## 成员变量

- transient
  transient关键字标记的成员变量不参与序列化过程。
  变量被transient修饰，变量将不再是对象持久化的一部分，该变量内容在序列化后无法获得访问。
  transient关键字只能修饰变量，而不能修饰方法和类。
```
    //存储元素数量
    transient int size = 0;
    
    //第一个节点的引用
    transient Node<E> first;
    
    //最后一个节点的引用
    transient Node<E> last;
```

    Invariant: (first == null && last == null) ||
              	(last.next == null && last.item != null)

这二个节点不变的两种情况：

1.首尾节点都是null 

2.尾节点的下个节点为null（尾节点的下个节点指向首节点）尾节点的数据不为null；

- Node 私有内部类
```
    private static class Node<E> {
        E item;			//存放数据的泛型
        Node<E> next;	//上一个节点
        Node<E> prev;	//下一个节点
    
        Node(Node<E> prev, E element, Node<E> next) {
            this.item = element;
            this.next = next;
            this.prev = prev;
        }
    }
```
## 构造函数

1. 默认无参构造
```
    public LinkedList() {
    }
```
2. 有参构造
```
    public LinkedList(Collection<? extends E> c) {
        //先创建空对象
        this();
        //将传入集合c中的元素添加到链表尾部
        addAll(c);
    }
```
## 重要方法

- 添加：add()
```
    public boolean add(E e) {
        //插入链表尾端
        linkLast(e);
        return true;
    }
    
    //插入尾端
    void linkLast(E e) {
        	//保留链表中最后一个节点引用
            final Node<E> l = last;
        	//新的节点对象
            final Node<E> newNode = new Node<>(l, e, null);
            //新节点为最后节点
        	last = newNode;
            if (l == null)
                //首节点上个节点为引用null
                //尾节点为null，没有链表为空
                first = newNode;
            else
                //尾节点下个节点引用指向新节点
                l.next = newNode;
        	//链表大小+1
            size++;
        	//结构修改次数
            modCount++;
        }
    
    //指定非null节点succ前插入元素E
    void linkBefore(E e, Node<E> succ) {
            // assert succ != null;
            final Node<E> pred = succ.prev;
            final Node<E> newNode = new Node<>(pred, e, succ);
            succ.prev = newNode;
            if (pred == null)
                first = newNode;
            else
                pred.next = newNode;
            size++;
            modCount++;
        }
```
插入元素默认是插入链表的尾端，如链表为空，新插入的节点就是首节点，首节点无上一节点；

链表不为空，将尾节点的中下节点的引用指向新节点；形成一个双向链表；

- addAll（）：指定索引位置插入集合中的元素到链表中
```
    public boolean addAll(int index, Collection<? extends E> c) {
        //索引是否越界
        checkPositionIndex(index);
    	//集合转化为数组
        Object[] a = c.toArray();
        //记录数组长度
        int numNew = a.length;
        if (numNew == 0)
            return false;
    
        //succ为index当前的节点，pred是当前节点的上一个节点
        Node<E> pred, succ;
        if (index == size) {
            //从尾部插入元素
            succ = null;
            pred = last;
        } else {
            //从链表头部或中间插入
            succ = node(index);
            pred = succ.prev;
        }
    	
        //遍历数组，循环插入节点
        for (Object o : a) {
            @SuppressWarnings("unchecked") E e = (E) o;
            Node<E> newNode = new Node<>(pred, e, null);
            if (pred == null)
                //pred == null是从头部插入
                first = newNode;
            else
                //修改下个节点的引用
                pred.next = newNode;
            //下个节点就新插入的节点
            pred = newNode;
        }
    
        //从尾部插入的话，处理last指针引用
        if (succ == null) {
            last = pred;
        } else {
            pred.next = succ;
            succ.prev = pred;
        }
    
        //修改链表大小
        size += numNew;
        modCount++;
        return true;
    }
    
    //查询指定索引节点
    Node<E> node(int index) {
            // assert isElementIndex(index);
    
        	//位运算>>相当于 / 2 折半查询
            if (index < (size >> 1)) {
                Node<E> x = first;
                for (int i = 0; i < index; i++)
                    x = x.next;
                return x;
            } else {
                Node<E> x = last;
                for (int i = size - 1; i > index; i--)
                    x = x.prev;
                return x;
            }
        }
```
1. 检查角标是否越界
2. 将集合转为数组，判断是否有元素，无元素直接返回；
3. 判断是否尾部插入（索引是否为size），还是头部或中间插入
4. 遍历数组，索引位置循环插入新节点
5. 更新size大小

- 删除：remove（）
```
    public E remove(int index) {
        //检查角标是否越界
        checkElementIndex(index);
        //获得索引位置的节点
        //取消链接节点
        return unlink(node(index));
    }
    
    //取消节点的链接
    E unlink(Node<E> x) {
            // assert x != null;
            final E element = x.item;
            final Node<E> next = x.next;
            final Node<E> prev = x.prev;
    
            if (prev == null) {
                //没有上一个节点，首节点
                first = next;
            } else {
                //prev的next指针指向当前节点的next节点
                prev.next = next;
                x.prev = null;
            }
    
        	//没有下一个节点，则传入的节点为尾节点
            if (next == null) {
                last = prev;
            } else {
                //将next下一节点的prev指针指向当前节点的prev节点
                next.prev = prev;
                x.next = null;
            }
    
            x.item = null;
            size--;
            modCount++;
            return element;
        }
 ```

- 删除指定索引元素

1. 检查角标是否越界
2. 获得索引位置的节点
3. 取消节点的链接
4. 获得删除节点的上下节点，修改上下节点的指针引用
   如果是首节点：直接将下节点作为首节点，否则将就修改上下节点的引用
5. 链表size改变，修改结构次数+1

- 删除链表第一次出现指定元素
```
      public boolean remove(Object o) {
          if (o == null) {
              for (Node<E> x = first; x != null; x = x.next) {
                  if (x.item == null) {
                      unlink(x);
                      return true;
                  }
              }
          } else {
              for (Node<E> x = first; x != null; x = x.next) {
                  if (o.equals(x.item)) {
                      unlink(x);
                      return true;
                  }
              }
          }
          return false;
      }
```
  1. 判断元素是否null
  2. 遍历链表，匹配元素，调用unlink移除指定元素的节点

- 获取：get（）
      public E get(int index) {
          //检查角标是否越界
          checkElementIndex(index);
          return node(index).item;
      }
      
  1. 检查角标是否越界
  2. 调用node（）节点，返回该索引位置元素
- 设置：set（）
```
      public E set(int index, E element) {
          checkElementIndex(index);
          Node<E> x = node(index);
          E oldVal = x.item;
          //修改指定节点的元素
          x.item = element;
          return oldVal;
      }
```      

Queue部分的方法


* peek()：返回头节点但不移除，头节点为null就返回null，时间复杂度O(1)
```
       public E peek() {
           final Node<E> f = first;
           return (f == null) ? null : f.item;
       }
```       
* element()：获取头节点但不移除，若头节点为null的话就抛出异常，时间复杂度O(1)

```
       public E element() {
           return getFirst();
       }
       
       public E getFirst() {
               final Node<E> f = first;
               if (f == null)
       			//首节点为null，抛异常
                   throw new NoSuchElementException();
               return f.item;
           }
```       
* poll()：移除头节点，头节点为null就返回null，时间复杂度O(1)
```
       public E poll() {
           final Node<E> f = first;
           return (f == null) ? null : unlinkFirst(f);
       }
  ```     
* remove()：移除头节点，若头节点为null的话就抛出异常，时间复杂度O(1)
```
       public E remove() {
           return removeFirst();
       }
       
       public E removeFirst() {
               final Node<E> f = first;
               if (f == null)
                   throw new NoSuchElementException();
               return unlinkFirst(f);
           }
       
```
* offer()：在尾部添加新节点，时间复杂度O(1)

```
public boolean offer(E e) {
	return add(e);
}
```
* push()：头部添加
```
public void addFirst(E e) {
    linkFirst(e);
}

//修改首节点
private void linkFirst(E e) {
        final Node<E> f = first;
        final Node<E> newNode = new Node<>(null, e, f);
        first = newNode;
        if (f == null)
            last = newNode;
        else
            f.prev = newNode;
        size++;
        modCount++;
    }
```
* pop()：移除首节点
```
public E pop() {
    return removeFirst();
}
```
# 总结

LinkedList是双向链表（双向队列）的数据结构，实现了List，Deque接口，是存取有序、增删快，可重复的特点；




