title: Synchronize与Lock锁
date: '2019-09-18 00:14:24'
updated: '2019-09-18 00:14:24'
tags: [JAVA基础, JAVASE, 锁机制]
permalink: /articles/2019/09/18/1568736864184.html
---
# Synchronize与Lock