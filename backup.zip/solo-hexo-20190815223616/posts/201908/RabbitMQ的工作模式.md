title: RabbitMQ的工作模式
date: '2019-08-12 22:50:57'
updated: '2019-08-14 21:59:16'
tags: [MQ消息队列]
permalink: /articles/2019/08/12/1565621457488.html
---
# RabbitMQ

### RabbitMQ的原理图

![null](https://note.youdao.com/yws/public/resource/03d1aa6777814ee36fcd169dc7b97bb4/xmlnote/6E24ACA993184021A00F3CDB679B2A11/2168)

### RabbitMQ的工作模式

RabbitMQ有以下几种工作模式 ：

1. **Work queues：工作队列模式**
    * 一个生产者可以对应多个消费者，只有一个队列，多个消费者监听同一个队列。
        
        * 特点：
            
            1、一条消息只会被一个消费者接收；
            
            2、rabbit采用轮询的方式将消息是平均发送给消费者的；
            
            3、消费者在处理完某条消息后，才会收到下一条消息；
            
        
        * 示意图
            
            ![null](https://note.youdao.com/yws/public/resource/03d1aa6777814ee36fcd169dc7b97bb4/xmlnote/1BFABB9FCF0649BEB7E21C7C785B7E42/2149)
            
2. **Publish/Subscribe：发布/订阅模式**
    
    * 特点：
        
        1、 一个队列也可以有多个消费者监听，可以和Work queues的一样。
        
        2、每个消费者可以监听自己的队列；
        
        3、交换机将消息转发到**绑定此交换机的每个队列，每个绑定交换机的队列都将接收到消息**
        
        * 示意图
            
            ![null](https://note.youdao.com/yws/public/resource/03d1aa6777814ee36fcd169dc7b97bb4/xmlnote/A03B35C2D11F4C19ADC6C49EB496B224/2160)
            
    * **publish/subscribe与work queues有什么区别。**
        
        * 区别
            
            1）work queues**不用定义交换机[使用默认交换机]**，而publish/subscribe**需要定义交换机。**
            
            2）publish/subscribe的生产方是面向交换机发送消息，work queues的生产方是面向队列发送消息(底层使用默认交换机)。
            
            3）publish/subscribe需要**设置队列和交换机的绑定**，work queues不需要设置，实质上workqueues会将**队列绑定到默认的交换机 。**
            
        * 相同
            
            所以两者实现的发布/订阅的效果是一样的，多个消费端监听同一个队列不会重复消费消息，有多个消费者，**RabbitMQ会采用轮询的方式负载均衡。**
            
3. **Routing：路由模式**
    
    * 特点
        
        1、每个消费者监听自己的队列，并重写消费方法即可。
        
        2、生产者将[指定routingkey]消息发给交换机，由交换机根据routingkey来转发投递消息到指定的队列。
        
    * 流程
        
        1. 声明交换机，指定交换机类型为*DIRECT*、名称
            
        2. 声明队列的信息，是否持久化独占连接等设置
            
        3. 交换机绑定指定队列，并指定了绑定的队列的routing Key，交换机通过rootingKey来将消息转发到指定的队列。
            
        4. 发送消息，发送到指定的交换机和消息的routingkey，消息体
            
    * 示意图
        
        ![null](https://note.youdao.com/yws/public/resource/03d1aa6777814ee36fcd169dc7b97bb4/xmlnote/1B89D6E7D4764A33B2D30A35FABFAC35/2231)
        
    * **Routing模式和Publish/subscibe有什么区别？**
        
        Routing模式要**求队列在绑定交换机时要指定routingkey**，消息会转发到符合routingkey的队列。
        
        * 应用场景：分布式下日志系统
            
            以消息的级别为路由key,发送到不的队列，进行记录日志。
            
        
        ![null](https://note.youdao.com/yws/public/resource/03d1aa6777814ee36fcd169dc7b97bb4/xmlnote/B86B2B8668054D5CB88F5ABD8346E193/2379)
        
4. **Topics：统配符模式**
    
    * 特点
        
        1. #：符号“#”匹配一个或多个词，也可以0个即空串
            
        2. *：符号 * 仅匹配一个词
            
        
        即交换机绑定队列时，**指定队列routingKey为统配符**,符合规则的就会转发到指定队列
        
        在发送消息时确定具体routingKey，符合匹配规则才转发到队列。
        
    * **Topics和routing 模式的区别：**
        
        * 区别：
            
            1. Topics的交换机类型是TOPIC，routing模式交换机类型是DIRECT
                
            
            2. Topics的队列routingKey是不精确到具体的，是匹配的字符串的
                
            
            3. routing的是精准匹配routingkey的。
                
            
            > 加强版，能够对routingKey，进行批量匹配，模糊匹配
            
    * 示意图
        
        ![null](https://note.youdao.com/yws/public/resource/03d1aa6777814ee36fcd169dc7b97bb4/xmlnote/AA4ABF065FC34DFE94A71C5C35DBBD4F/2388)
        
5. **Header：头模式（key=value的形式）**
    
    * header模式与routing不同的地方在于，**header模式取消routingkey，使用header中的 key/value（键值对）来匹配队列。**
        
6. **RPC模式**
    
    * RPC即客户端远程调用服务端的方法 ，使用MQ可以实现RPC的异步调用，基于Direct交换机来实现；
        
    * 流程
        
        1、客户端即是生产者就是消费者，向RPC请求队列发送RPC调用消息，同时监听RPC响应队列。
        
        2、服务端监听RPC请求队列的消息，收到消息后执行服务端的方法，得到方法返回的结果
        
        3、服务端将RPC方法 的结果发送到RPC响应队列
        
        4、客户端（RPC调用方）监听RPC响应队列，接收到RPC调用结果。
        
    * 示意图
        
        ![null](https://note.youdao.com/yws/public/resource/03d1aa6777814ee36fcd169dc7b97bb4/xmlnote/1E81503A6B3140C1B31AC52473006E52/2438)
        
    
    ### 交换机类型
    
    1. BuiltinExchangeType.FANOUT：扇型交换机——>**Publish/Subscribe发布订阅模式**
        
        * 将消息路由给绑定到它身上的所有队列，即所有队列都有一份消息;
            
        * 示意图
            
        
        ![null](https://note.youdao.com/yws/public/resource/03d1aa6777814ee36fcd169dc7b97bb4/xmlnote/B746F5D1A3FE4E73B4B554C8CFE0A637/2465)
        
    2. BuiltinExchangeType.DIRECT:直连交换机——>**Routing路由模式**
        
        * 根据消息携带的路由键（routing key）将消息投递给对应（routing key）的队列
            
        * 示意图
            
        
        ![null](https://note.youdao.com/yws/public/resource/03d1aa6777814ee36fcd169dc7b97bb4/xmlnote/110A297E5C6445D1BF1E22AE4BACE62F/2462)
        
    3. BuiltinExchangeType.TOPIC:主题交换机[通配符]——>**Topics模式**
        
        * 队列通过路由键绑定到交换机上，然后，交换机根据消息里的路由值，将消息路由给一个或多个绑定队列。
            
        * 示意图
            
        
        ![null](https://note.youdao.com/yws/public/resource/03d1aa6777814ee36fcd169dc7b97bb4/xmlnote/3A59D9A16C0D495E824D4D11D15F2E2C/2467)
        
    4. BuiltinExchangeType.HEADERS:头交换机——>**Header模式**
        
        * 使用多个消息属性来代替路由键建立路由规则。通过判断消息头的值能否与指定的绑定相匹配来确立路由规则。
            
            * 匹配规则x-match有下列两种类型：
                
            
            1. x-match = all ：表示所有的键值对都匹配才能接受到消息
                
            2. x-match = any ：表示只要有键值对匹配就能接受到消息
                
        * 示意图
            
        
        ![null](https://note.youdao.com/yws/public/resource/03d1aa6777814ee36fcd169dc7b97bb4/xmlnote/AB055249717746818BDC215D3C66E59B/2473)
        
    
    ### RabbitMQ连接发送消息流程
    
    * 生产者
        
    
    1. 通过连接工厂ConnectionFactory，设置连接参数端口IP等[AMQP协议，就是TCP协议的应用层协议]，生产连接，能够连接rabbitMQ的服务。
        
    2. 通过**连接获得通道[一个连接可以有多个通道，通道可以理解为一次会话]**。
        
        生产者通道连接的是交换机。通过通道向RabbitMQ的交换机发送消息。
        
    3. 声明交换机和队列，并设置相关属性
        
        声明交换机：交换机名称，交换机类型
        
        声明队列：队列名称、队列是否持久化、是否独占连接、队列不再使用是否自动删除，队列参数参存活时间等..
        
    4. 交换机绑定队列，指定队列的名称、交换机名称、路由key
        
    
    5. 发送消息。可以指定交换机名称，路由key，队列名称、消息体等..
        
    
    * 消费者
        
        1.2.3同上，都是先和rabbitMQ建立连接和获得通道，[可以不做声明一次即可，声明交换机和队列]，**消费者连接到相应的Queue上建立Channel通道。**
        
        4. 消费者监听队列，队列名称、是否自动回复、消费方法等参数
            
        
        5. 定义消费方法，创建**DefaultConsumer**对象，重写handleDelivery（）方法，进行消费消息。
            
            * 重写的方法：
                
                handleShutdownSignal方法 ：
                
                当Channel与Conenction关闭的时候会调用
                
                handleCancelOk方法：
                
                会在其它方法之前调用，可以获得消费者标签
                
                > handleCancelOk与handleCancel消费者可以显式或者隐式的取消订阅的时候调用，也可以通过channel.basicCancel方法来显式的取消一个消费者订阅，会首先触发handleConsumeOk方法，之后触发handleDelivery方法，最后才触发handleCancelOk方法。
                
    
    ### RabbitMQ的工作流程介绍
    
    1、建立信息。生产者定义需要发送消息的结构和内容。
    
    2、建立Conection和Channel。由Publisher和Consumer创建连接，连接到Broker[rebbiteMQ]的物理节点上，同时建立Channel。Channel是建立在Connection之上的，一个Connection可以建立多个Channel。Publisher连接Virtual Host 建立Channel，Consumer连接到相应的Queue上建立Channel。
    
    3、声明交换机和队列。声明一个消息交换机（Exchange）和队列（Queue），并设置相关属性。
    
    4、发送消息。由Publisher发送消息到Broker中的Exchange中
    
    5、路由转发。RabbitMQ收到消息后，根据消息指定的Exchange(交换机) 来查找Binding(绑定) 然后根据规则（Routing Key）分发到不同的Queue。这里就是说使用Routing Key在消息交换机（Exchange）和消息队列（Queue）中建立好绑定关系，然后将消息发送到绑定的队列中去。
    
    6、消息接收。Consumer监听相应的Queue，一旦Queue中有可以消费的消息，Queue就将消息发送给Consumer端。
    
    7、消息确认。当Consumer完成某一条消息的处理之后，需要发送一条ACK消息给对应的Queue。
    
    #### 队列对ACK的处理有以下几种情况：
    
    * Consumer**接收了消息，发送ack**，RabbitMQ会**删除队列中这个消息**，接着发送另一条消息给Consumer。
        
    * Consumer接收了消息, 但在**发送ack之前断开Channel**，RabbitMQ会认为这条消息**没有被deliver（递送）**,如果有**其他的Channel**，会该消息将**被发送给另外的Channel**。如果没有，当在Consumer再次连接的时候，这条消息会被redeliver（重新递送）。
        
    * consumer接收了消息，但是忘记了ack,RabbitMQ不会重复发送消息。
        
    * 新版RabbitMQ还支持Consumer reject某条（类）消息，可以通过设置requeue参数中的reject为true达到目地，那么Consumer将会把消息发送给下一个注册的Consumer。
        
    
    ### 绑定
    
    绑定（Binding）是交换机（Exchange）将消息（Message）路由给队列（Queue）所需遵循的规则。
    
    #### Routing Key
    
    一个可选的路由键（Routing Key）属性给某些类型的交换机。
    
    路由键的意义在于从发送给交换机的众多消息中选择出某些消息，将其路由给绑定的队列。