title: Spring源码环境搭建
date: '2019-08-11 23:49:23'
updated: '2019-08-11 23:49:23'
tags: [spring源码深度解析]
permalink: /articles/2019/08/11/1565538563567.html
---
# Spring源码环境搭建
## 搭建环境
*  本机环境：
	* JDK1.8
	* Gradle 4.8
	* idea 2019.1.2
	* Git 
* 环境搭建
	*  Gradle 
		> 本人常用maven，Gradle建议使用国内阿里云镜像源，本人安装此教程搭建[https://www.cnblogs.com/yaozhixiang/articles/10210812.html](https://)
	* JDK、Git、idea不再详细说明
	* Spring 5.0.x源码git链接 [https://github.com/spring-projects/spring-framework/tree/5.0.x](https://)
> ps:git clone 拉去代码是非常慢！！！借助梯子会快很多，本人参考：[https://blog.csdn.net/havedoor/article/details/83350768](https://)、[https://blog.csdn.net/MENGHUANBEIKE/article/details/74001756](https://)

<br>
## 导入Spring源码
1. idea以gradle的方式导入，开启自动导入，注意不要使用maven导入
[![image.png](https://img.hacpai.com/file/2019/08/image-3e74ded0.png)
](https://)
2. 导入后等待idea自动下载依赖，全部绿的就是成功下载依赖成功，红的我也没遇到（滑稽）
3. 手动build编译查看是否有缺失依赖
![image.png](https://i.loli.net/2019/08/11/ijHN24LvOp81Dc3.png)
4. 解决缺少依赖
* 缺少的jar为：spring-cglib-repack-3.2.4.jarspring-objenesis-repack-2.4.jar
进入spring项目目录CMD执行：**gradle objenesisRepackJar**和**gradle cglibRepackJar**命令
![image.png](https://img.hacpai.com/file/2019/08/image-37b09fe0.png)
 另一种解决方式
依次点击执行
![image.png](https://img.hacpai.com/file/2019/08/image-2f0fd073.png)
![image.png](https://img.hacpai.com/file/2019/08/image-02322bd2.png)
> 参考：[https://blog.csdn.net/qq_40400960/article/details/83867469](https://)

5 . 解决其他error
全部**注释**即可！
![image.png](https://img.hacpai.com/file/2019/08/image-cf087bf3.png)
![image.png](https://img.hacpai.com/file/2019/08/image-dbdcd242.png)
6. 项目已经可以正常编译，完成
### 待继续学习......


