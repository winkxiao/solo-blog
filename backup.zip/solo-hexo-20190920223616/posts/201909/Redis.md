title: Redis
date: '2019-09-18 00:08:13'
updated: '2019-09-18 00:08:13'
tags: [Redis, NoSql]
permalink: /articles/2019/09/18/1568736493061.html
---
# Redis