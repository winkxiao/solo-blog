title: Redis
date: '2019-09-23 23:46:54'
updated: '2019-09-25 15:12:53'
tags: [Nosql, 缓存]
permalink: /articles/2019/09/23/1569253614813.html
---
# Redis
Redis数据结构
key：value格式的数据，其中key都是字符串，value有5种不同的数据结构

value数据结构
	字符串：String	最大不超过512M
	存储： set key value
set key value [ex seconds] [px milliseconds] [nx|xx]
·ex seconds：为键设置秒级过期时间。
·px milliseconds：为键设置毫秒级过期时间。
·nx：键必须不存在，才可以设置成功，用于添加。
·xx：与nx相反，键必须存在，才可以设置成功，用于更新。
	获取： get key
	删除： del key
	哈希类型：hash
	存储： hset key field value
	获取：
		hget key field: 获取指定的field对应的值
		hgetall key：获取所有的field和value
	删除： hdel key field
	列表类型：list		有序[索引]，可重复
	 添加： lpush key value: 将元素加入列表左表   
 				 rpush key value：将元素加入列表右边
	获取：lrange key start end ：范围获取
	删除：lpop key： 删除列表最左边的元素，并将元素返回 ，右同理
blpop key [key ...] timeout	阻塞式弹出
  brpop key [key ...] timeout
·key[key...]：多个列表的键
·timeout：阻塞时间（单位：秒）为0一直阻塞
	集合类型：
set 集合内的增删改查，同时还支持多个集合取交集、并集、差集。
	存储：sadd key value
	获取：smembers key:获取set集合中所有元素
	 删除：srem key value:删除set集合中的某个元素	
有序集合类型：sortedset 元素不能重复，但是score可以重复
	存储：zadd key score value
	获取：zrange key start end [withscores分数]
	删除：zrem key value

与传统关系型数据库对比和优势
优势
	1.redis型数据库存储在内存中，mysql之类存储在硬盘里
	2.mysql数据之间是有联系，redis数据是没有关系的
	3.查询关系数据库速度慢，nosql查询快
缺点：不提供关系型数据库对事务的处理。

与关系型数据库的对比
	1.成本：nosql数据库简单易部署，基本都是开源软件，而Oracle之类的关系型数据库需要成本
	2.查询速度：nosql数据库将数据存储于内存之中，关系型数据库存储在硬盘中。查询快
	3.存储的数据格式多样，存储格式是key,value形式，可以存基本类型，对象或者是集合等各种格式，而数据库则只支持基础类型。
	4.扩展性：关系型数据库有类似join这样的多表查询机制的限制导致扩展很艰难。noSql可以随意加keyvalue。


redis单线程为什么速度还快？
第一，纯内存访问
第二，非阻塞I/O、多路复用I/O
第三，单线程避免了线程切换和竞态产生的消耗。
存在的问题：
某个命令执行过长，会造成其他命令的阻塞。

分布式锁一般有三种实现方式：
1. 数据库乐观锁；
redis实现锁的
setex key seconds[过期时间] value 	设置key并加上key过期时间
setnx key value					key不存在才能设置成功


2. 基于Redis的分布式锁；
3. 基于ZooKeeper的分布式锁
分布式锁可用，至少要确保锁的实现满足四个条件：
互斥性。在任意时刻，只有一个客户端能持有锁。
不会发生死锁。即使有一个客户端在持有锁的期间崩溃而没有主动解锁，也能保证后续其他客户端能加锁。即设置key过期时间
具有容错性。只要大部分的Redis节点正常运行，客户端就可以加锁和解锁。
解铃还须系铃人。加锁和解锁必须是同一个客户端，客户端自己不能把别人加的锁给解了。


redis能否将数据持久化，如何实现？
能，将内存中的数据异步写入硬盘中，两种方式：RDB（默认）和AOF

RDB持久化原理：通过bgsave命令触发，然后父进程执行fork操作创建子进程，子进程创建RDB文件，根据父进程内存生成临时快照文件，完成后对原有文件进行原子替换

按照配置的指定时间将内存中的数据快照到磁盘中，创建dump.rdb文件，redis启动时恢复内存中。[debug reload命令重新加载Redis、shutdown也触发]
优点：
是紧凑压缩的二进制文件，Redis加载RDB恢复数据快于AOF的方式。
缺点：
RDB开销较大，非实时持久化，最后一次持久化后的数据可能会丢失；
流程图


AOF持久化原理：开启后，Redis每执行一个修改数据的命令，都会把这个命令添加到AOF文件中。
两种方式触发：有写操作就写、每秒定时写（也会丢数据）。
AOF的工作流程操作：命令写入（append）、文件同步（sync）、文件重写（rewrite）、重启加载（load）
 


优点：实时持久化。
缺点：AOF文件体积会逐渐变大，需要定期执行重写操作来降低文件体积，加载慢


redis的常见使用命令：
String：
mget key： 批量获取值
mset key value key1 value1：批量设置值
incr key：计数，自增，还有自减等


列表List：
lindex key index：获得指定索引的元素
llen key：获得集合长度
lrem key count value：删除指定元素
·count>0，从左到右，删除最多count个元素。
·count<0，从右到左，删除最多count绝对值个元素。
·count=0，删除所有。
lset key index newValue：修改指定索引下标的元素
blpop key [key ...] timeout：阻塞式弹出
brpop key [key ...] timeout
阻塞式注意点：
第一点：如果是多个键，那么brpop会从左至右遍历键，一旦有一个键能弹出元素，客户端立即返回1。
第二点，多个客户端对同一个键执行brpop，最先执行brpop命令的客户端可以获取到弹出的值。

集合set
scard key	：计算集合元素大小
sismember key element：判断元素是否在集合中，存在返回1
sinter key [key ...]：求多个集合的交集，共同关注等
suinon key [key ...]：求多个集合的并集，
sdiff key [key ...]：求多个集合的差集，即两个集合不相同的元素集合

将操作结果保存
sinterstore destination key [key ...]
suionstore destination key [key ...]
sdiffstore destination key [key ...]

哈希类型
hincrby key field	：对哈希里的字段+1
hincrbyfloat key field：浮点数

redis的使用场景：
String类型：
1.缓存功能
2.计数
视频播放数系统就是使用Redis作为视频播放数计数的基础组件，用户每播放一次视频，相应的视频播放数就会自增1：【需要考虑的：防作弊、按照不同维度计数，数据持久化到底层数据源等。】
3.共享Session
使用Redis将用户的Session进行集中管理【需要保证：保证Redis是高可用和扩展性】
4.限速，限制次数
例如短信验证码次数
phoneNum = "138xxxxxxxx";
key = "shortMsg:limit:" + phoneNum;
// SET key value EX 60 NX
isExists = redis.set(key,1,"EX 60","NX");
if(isExists != null || redis.incr(key) <=5){
    // 通过
}else{
    // 限速
}


2. 哈希类型
存储用户对象信息，对象会将序列化成字符串类型：将用户信息序列化后用一个键值对保存。
缺点：序列化和反序列化有一定的开销，每次更新属性都需要把全
部数据取出进行反序列化，更新后再序列化到Redis中。

3. 列表类型List
1.消息队列
Redis的lpush+brpop命令组合即可实现阻塞队列，生产者客户端使用lrpush从列表左侧插入元素，多个消费者客户端使用brpop命令阻塞式的“抢”列表尾部的元素【只会有一个客户端】，多个客户端保证了消费的负载均衡和高可用性。

2.文章列表
是否
组合特点：开发结合
·lpush+lpop=Stack（栈）
·lpush+rpop=Queue（队列）
·lpsh+ltrim[截取]=Capped Collection（有限集合）
·lpush+brpop=Message Queue（消息队列）

4. set集合
标签（tag）系统：可以进行对用户的数据进行分析，分析行为喜好，做出不同的推荐
注意：用户和标签的关系维护应在一个事务内执行，防止命令失败的数据不一致。
组合：与开发结合
·sadd=Tagging（标签）
·spop+andmember=Random item（生成随机数，比如抽奖）
·sadd+sinter=Social Graph（社交需求）

5. sortedset有序集合
排行榜系统

列表、集合和有序集合三者的异同点



键key的管理：
键重命名
rname oldkey newkey	重命名key
renamenx	当newkey不存在才能改名成功
键过期操作：
·expire key seconds：键在seconds秒后过期	键不存在返回0，过期时间为- 则直接删除
·expireat key timestamp：键在秒级时间戳timestamp后过期
ttl key 查询剩余过期时间
persist key ：清除key的过期时间[字符串set key也清除]
迁移键值：
dump+restore：
dump key：  ①源Redis，dump命令将键值序列化，格式是RDB格式
restore key ttl value： ②目标Redis上，restore命令将序列化的值进行复原，ttl参数代表过期时间，如果ttl=0代表没有过期时间。

migrate	
migrate host port key|"" destination-db timeout [copy] [replace] [keys key [key 
将dump、restore、del三个命令进行组合，具有原子性。
·host：目标Redis的IP地址。
·port：目标Redis的端口。
·key|""：此处是要迁移的键，需要迁移多个键，此处为空字符串""。
·destination-db：目标Redis的数据库索引，例如要迁移到0号数据库，这里就写0。
·timeout：迁移的超时时间（单位为毫秒）。
·[copy]：如果添加此选项，迁移后并不删除源键。
·[replace]：如果添加此选项，migrate不管目标Redis是否存在该键都会
正常迁移进行数据覆盖。
·[keys key[key...]]：迁移多个键，例如要迁移key1、key2、key3，此处填
写“keys key1 key2 key3”。

move、dump+restore、migrate三个命令比较


清楚数据库，删除所有键：
flushdb/flushall：用于清除数据库，区别的是flushdb只清除当前数据库，flushall会清除所有数据库。


redis的事务：
multi	：代表开始事务
set，add等一些操作一些动作	会暂存在redis中。
[discard]	:停止事务
exec	：提交事务，中间的操作才算执行完成

出现异常处理情况：
语法错误：
整个事务无法执行，即不改变
运行时错误：
事务不会回滚，且命令已经执行修改成功。通过watch命令监控key，没有被修改才能执行成功。【类似乐观锁】


发布订阅：使用场景消息队列
发布消息：发布消息到指定频道
publish channel[频道] message
订阅消息：可以订阅多个频道，订阅的在线客户端都可以收到[进入订阅状态，只能订阅其他频道或退出]
subscribe channel [channel ...]
psubscribe pattern [pattern...]		：按模式订阅，即条件 
取消订阅：
unsubscribe [channel [channel ...]]	：取消指定频道的订阅
punsubscribe [pattern [pattern ...]]	：按模式取消订阅，例如；it*取消it开头的频道订阅
查询订阅：
可以查询活跃频道等略...


主从复制[slaveof命令]：建立复制后，它们之间长连接并彼此发送心跳命令
复制流程：
1）保存主节点（master）信息。
2）从节点与主节点建立网络连接
3）发送ping命令
检测主从之间网络套接字是否可用。
检测主节点当前是否可接受处理命令
4）权限验证
5）同步数据集。开始同步复制
6）命令持续复制。保证主从数据一致性。

从节点作用：
第一，作为主节点的一个备份，主节点出故障，从节点可以备用，并且保证数据尽量不丢失（主从复制是最终一致性）。
第二，从节点可扩展主节点的读能力，从节点可帮助主节点分担读压力。

Redis高可用：主从复制

故障转移过程【主节点故障，切换从节点】：
原生流程：
1.主节点故障，客户端连接失败，从节点复制失败
2.主节点无法正常启动，选出一个从节点slave-1），对其执行slaveof no one命令使其成为新的主节点。
3.从节点成为主节点，通知客户端连接
4.从节点复制连接新的主节点
5.原主节点恢复，变成从节点复制连接
哨兵监控处理故障：
1.哨兵节点监控redis节点，发现主节点故障不可达
2.多个哨兵节点对主节点故障达成一致[投票防止误判]，选举新的主节点
3.然后执行原生处理故障流程

哨兵模式主要功能有一下几点
1、监控redis是否良好地运行;
2、如果发现某个redis节点运行出现状况，能够通知【发布订阅模式】另外一个进程(例如它的客户端);切换从节点
3、能够进行自动切换。当一个master节点不可用时，能够选举出master的多个slave(如果有超过一个slave的话)中的一个来作为新的master,其它的slave节点会将它所追随的master的地址改为被提升为master的slave的新地址。
4、哨兵为客户端提供服务发现，客户端链接哨兵，哨兵提供当前master的地址然后提供服务，如果出现切换，也就是master挂了，哨兵会提供客户端一个新地址。

内存回收策略：删除过期数据：
惰性删除：
主节点每次处理读取get命令时，都会检查键是否超时，如果超时则执行del命令删除键对象返回null，之后del命令也会异步发送给从节点。
定时删除：
Redis主节点在内部定时任务循环采样一定数量的键，发现采样的键过期时执行del命令，之后再同步给从节点。

内存优化：
scan+object idletime命令批量查询哪些键长时间未被访问，找出长时间不访问的键进行清理，可降低内存占用
高并发场景，可以将字符串长度控制在39字节内，减少redisObject分配内存。
缩减键值对象：降低Redis内存使用最直接的方式就是缩减键（key）和值（value）的长度。value：对业务对象精简去除无用属性值，高效序列化工具
整数共享对象池：Redis内部维护[0-9999]的整数对象池
可以节约内存，建议直接使用整数对象，会复用
字符串优化：减少字符串频繁修改操作，改用set直接修改。json等格式采用hash结构的二级结构存储
控制键的数量：可以将大量键存入hash结构中
Redis阻塞
发现阻塞：CacheCloud 框架监控
通过添加一个Appender[附加组件]来监控redis异常行为并记录日志。

阻塞的原因：
内在原因：
API或数据结构使用不合理：存入大量大对象，或在高并发时执行时间复杂度高的API。
CPU饱和，效率低
持久化阻塞：开启持久化机制，而数据量过大
外在原因：
CPU竞争：
进程竞争其他进程与redis进行抢资源
多核CPU建立多个redis实例
网络问题：延迟、掉线、拒绝连接
内存交换：保证有充足可用内存、设置redis的最大可用内存、降低swap优先级


redis 和 memcached 的区别
1. redis支持更丰富的数据类型（支持更复杂的应用场景）：Redis不仅仅支持简单的key-value
类型的数据，同时还提供list，set，zset，hash,sortset数据结构的存储。memcache支持简单的数据类型，String。
2.Redis支持数据的持久化，可以将内存中的数据保持在磁盘中，重启的时候可以再次加载进行使用,而Memecache把数据全部存在内存之中。
3. 集群模式：memcached没有原生的集群模式，需要依靠客户端来实现往集群中分片写入数据；但是 redis 3.0支持一键集群。
4. Memcached是多线程，非阻塞IO复用的网络模型；Redis使用单线程的多路 IO 复用模型。

Redis缓存击穿问题：
一种特殊的热点key：在某一段时间被高并发访问。或是经常被访问的key。
缓存穿透的概念：
缓存中的Key在某一个时间段过期，恰好有大量请求对该key访问，发现key过期，这些请求会访问DB加载数据并回设到缓存中，然而大量请求可能会压垮后端DB。
如何解决：
是使用mutex（互斥锁）。简单地来说，就是在缓存失效的时候（判断拿出来的值为空），不是立即去load db，而是先使用缓存工具的某些带成功操作返回值的操作（比如Redis的SETNX或者Memcache的ADD）去set一个mutex key，当操作返回成功时，再进行load db的操作并回设缓存（保证了只有一个线程从DB中加载数据）；否则，就重试整个get缓存（证明已有线程在重新加载数据）的方法。
public String get(key) {
      String value = redis.get(key);      if (value == null) { //代表缓存值过期
          //设置3min的超时，防止del操作失败的时候，下次缓存过期一直不能load db
          if (redis.setnx(key_mutex, 1, 3 * 60) == 1) {  //代表设置成功
               value = db.get(key);
                      redis.set(key, value, expire_secs);
                      redis.del(key_mutex);
              } else {  //这个时候代表同时候的其他线程已经load db并回设到缓存了，这时候重试获取缓存值即可
                      sleep(50);
                      get(key);  //重试
              }
          } else {             
           return value;      
          }
  }

